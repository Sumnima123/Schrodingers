package net.code.flightplan;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


public interface CourseInfoRepo extends JpaRepository<CourseInfo, Integer> {
	
	@Modifying
    @Query(value = "SELECT title FROM courseInfo WHERE subject LIKE :term%",
            nativeQuery = true)
	
    List<String> getByTitle(String term);
	
}
