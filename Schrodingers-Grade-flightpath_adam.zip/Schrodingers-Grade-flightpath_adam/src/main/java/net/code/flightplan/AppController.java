package net.code.flightplan;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**

//import com.edw.springautocomplete.bean.Test;

import org.aspectj.weaver.ast.Test;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
*/
@Controller
public class AppController {
	
	@Autowired
	private CourseInfoService service;//If it's not used then what are we using the repo for?
  // @Autowired 
	//private CourseInfoRepo course;
	
	//Returns just the index page 
	@RequestMapping("/")
	public String viewHomePage(Model model)
	{
		
		return "index";
	}
	
	
	   @RequestMapping("/new") 
	  public String editSchedule(Model model)
	   { 
		   return "Schedule"; 
	   }
	
	   
	@RequestMapping(value = "/titleAutocomplete") 
	@ResponseBody 
    public List<String> autoName(@RequestParam(value = "term", required = false, defaultValue = "")String term)
	{
     
		List<String> designation = service.getByTitle(term);
        return designation;
        
        //Exception
    }
	
	/**@RequestMapping(value="/autocomplete")
	@ResponseBody
	
    @RequestMapping("/new")
    @ResponseBody
    public List<String> autoName(@RequestParam(value = "term", required = false, defaultValue = "")String term){
     
		//return course.getByTitle(term);
		List<String> designation = course.getByTitle(term);
        return designation;
        
        //Exception
    }*/
	
}
