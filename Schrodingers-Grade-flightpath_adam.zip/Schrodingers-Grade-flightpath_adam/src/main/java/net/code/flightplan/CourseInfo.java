package net.code.flightplan;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CourseInfo {
	//Variables 
	
		private int crn;
		private String subject;
		private String title;
		private int capacity;
		private float credit;
		private String level;
		private String instuctor;
		
		//Constructor 
		
		//CRN
		@Id
		public int getCrn() {
			return crn;
		}
		public void setCrn(int crn) {
			this.crn = crn;
		}
		//Subject
		public String getSubject() {
			return subject;
		}
		public void setSubject(String subject) {
			this.subject = subject;
		}
		//Title
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		//Instructor
		public String getInstuctor() {
			return instuctor;
		}
		public void setInstuctor(String instuctor) {
			this.instuctor = instuctor;
		}
		//Credit
		public float getCredit() {
			return credit;
		}
		public void setCredit(float credit) {
			this.credit = credit;
		}
		//Capacity
		public int getCapacity() {
			return capacity;
		}
		public void setCapacity(int capacity) {
			this.capacity = capacity;
		}
		//Level
		public String getLevel() {
			return level;
		}
		public void setLevel(String level) {
			this.level = level;
		}
}
		
		
