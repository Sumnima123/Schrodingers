package net.code.flightplan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightplanApplication 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(FlightplanApplication.class, args);
	}

}
